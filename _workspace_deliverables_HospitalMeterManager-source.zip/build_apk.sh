#!/bin/bash
# Rebuild the Hospital Meter Manager APK from source (no Gradle).
set -e
cd /workspace
BT=/opt/android-sdk/build-tools/35.0.0
AJ=/opt/android-sdk/platforms/android-34/android.jar

echo "== 1. Sync web app into assets (strip dev-only ninja script) =="
rm -rf android_wrapper/assets
mkdir -p android_wrapper/assets
cp -r hospital_meter_webapp/. android_wrapper/assets/
sed -i '/ninja-daytona-script/d' android_wrapper/assets/index.html
grep -c "ninja-daytona" android_wrapper/assets/index.html || true

cd android_wrapper

echo "== 2. Compile resources =="
rm -rf build/compiled build/gen build/classes build/dex
mkdir -p build/compiled build/gen build/classes build/dex
$BT/aapt2 compile --dir res -o build/compiled/res.zip

echo "== 3. Link resources + manifest + assets =="
$BT/aapt2 link -o build/base.apk -I $AJ --manifest AndroidManifest.xml \
    -A assets --java build/gen --min-sdk-version 24 --target-sdk-version 34 \
    --version-code 1 --version-name 1.0.0 build/compiled/res.zip

echo "== 4. Compile Java =="
javac -source 8 -target 8 -bootclasspath $AJ -classpath $AJ \
    -d build/classes src/com/techarslan/hospitalmeter/*.java \
    build/gen/com/techarslan/hospitalmeter/R.java 2>&1 | grep -v "bootstrap class path\|source value 8\|target value 8\|deprecat" || true

echo "== 5. Dex =="
$BT/d8 --lib $AJ --min-api 24 --output build/dex $(find build/classes -name '*.class')

echo "== 6. Package + align + sign =="
cd build
cp base.apk unsigned.apk
zip -j -q unsigned.apk dex/classes.dex
$BT/zipalign -f -p 4 unsigned.apk aligned.apk
$BT/apksigner sign --ks release.keystore --ks-pass pass:hospitalmeter \
    --key-pass pass:hospitalmeter --ks-key-alias hospitalmeter \
    --out HospitalMeterManager.apk aligned.apk

echo "== 7. Verify =="
$BT/apksigner verify --print-certs HospitalMeterManager.apk | head -4
$BT/aapt2 dump badging HospitalMeterManager.apk | head -6
ls -la HospitalMeterManager.apk
echo "BUILD DONE"
