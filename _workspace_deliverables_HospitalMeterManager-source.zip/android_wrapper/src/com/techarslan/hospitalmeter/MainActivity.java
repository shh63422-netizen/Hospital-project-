package com.techarslan.hospitalmeter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Hospital Meter Manager — native WebView shell.
 * Loads the offline web application bundled in assets/ and exposes a small
 * JavaScript bridge so reports can be saved / shared / printed natively.
 *
 * Software Developed By Tech Arslan Software Solutions 03200199895
 */
public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        try { s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); } catch (Throwable ignored) {}

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        // Let the web app handle navigation first; it calls AndroidBridge.exitApp()
        // when the user is already on the dashboard.
        if (web != null) {
            web.evaluateJavascript("window.App ? App.back() : null", null);
        } else {
            super.onBackPressed();
        }
    }

    /** JavaScript bridge exposed to the web app as window.AndroidBridge */
    public class Bridge {

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(new Runnable() {
                public void run() { finish(); }
            });
        }

        @JavascriptInterface
        public void savePdf(String base64, String filename) {
            File f = writePdf(base64, filename);
            if (f != null) openPdf(f, false);
        }

        @JavascriptInterface
        public void sharePdf(String base64, String filename) {
            File f = writePdf(base64, filename);
            if (f != null) openPdf(f, true);
        }

        @JavascriptInterface
        public void printPdf(String base64, String filename) {
            File f = writePdf(base64, filename);
            if (f != null) openPdf(f, false);
        }

        @JavascriptInterface
        public String appVersion() {
            return "1.0.0";
        }
    }

    private File writePdf(String base64, String filename) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            File dir = new File(getFilesDir(), "reports");
            if (!dir.exists()) dir.mkdirs();
            if (filename == null || filename.trim().isEmpty()) filename = "report.pdf";
            File f = new File(dir, filename);
            FileOutputStream out = new FileOutputStream(f);
            out.write(data);
            out.flush();
            out.close();
            return f;
        } catch (Exception e) {
            Toast.makeText(this, "Could not save report", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void openPdf(File f, boolean share) {
        Uri uri = Uri.parse("content://" + PdfProvider.AUTHORITY + "/" + f.getName());
        Intent i;
        if (share) {
            i = new Intent(Intent.ACTION_SEND);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_STREAM, uri);
        } else {
            i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/pdf");
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "Open report"));
        } catch (Exception e) {
            Toast.makeText(this, "No app available to open PDF", Toast.LENGTH_SHORT).show();
        }
    }
}
