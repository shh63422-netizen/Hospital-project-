/* ============================================================
   Sync — offline-first, two-way cloud sync engine
   States: offline | online | syncing | synced | error
   Push local pending changes, then pull remote changes and merge.
   ============================================================ */
(function (global) {
  'use strict';

  const Sync = {
    state: 'offline',
    lastError: '',
    lastPulled: 0,
    listeners: [],

    init() {
      window.addEventListener('online', () => Sync.refresh());
      window.addEventListener('offline', () => Sync.refresh());
      Sync.refresh();
      setInterval(Sync.refresh, 15000);
      // auto-sync shortly after boot if configured + online
      setTimeout(() => {
        const s = DB.settings();
        if (s.endpoint && Sync.isOnline() && DB.pendingCount() > 0) Sync.syncNow(true);
      }, 4000);
    },

    on(fn) { Sync.listeners.push(fn); },
    emit() { Sync.listeners.forEach(fn => { try { fn(Sync.state, Sync.lastError); } catch (e) {} }); },

    isOnline() { return navigator.onLine; },

    refresh() {
      if (Sync.state === 'syncing') return;
      Sync.state = Sync.isOnline() ? 'online' : 'offline';
      Sync.emit();
    },

    label() {
      return { offline: 'Offline', online: 'Online', syncing: 'Syncing\u2026', synced: 'Synced', error: 'Sync Error' }[Sync.state] || 'Offline';
    },

    pendingCount() { return DB.pendingCount(); },

    /* Normalise whatever the user typed into a full /api/sync URL */
    endpointUrl() {
      let e = (DB.settings().endpoint || '').trim();
      if (!e) return '';
      if (!/^https?:\/\//i.test(e)) e = 'https://' + e;
      e = e.replace(/\/+$/, '');
      if (!/\/api\/sync$/i.test(e)) e += '/api/sync';
      return e;
    },

    /* Derive the health URL from the sync endpoint */
    healthUrl() {
      const e = Sync.endpointUrl();
      if (!e) return '';
      return e.replace(/\/api\/sync$/i, '/api/health');
    },

    headers() {
      const s = DB.settings();
      const h = { 'Content-Type': 'application/json' };
      if (s.token) h['Authorization'] = 'Bearer ' + s.token;
      if (s.group) h['X-Group'] = s.group;
      return h;
    },

    /* Quick connectivity check used by the Settings screen */
    async testConnection() {
      const url = Sync.healthUrl();
      if (!url) { U.toast('Enter a server URL first', 'warn'); return false; }
      if (!Sync.isOnline()) { U.toast('No internet connection', 'warn'); return false; }
      try {
        const res = await fetch(url, { method: 'GET', headers: Sync.headers() });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json().catch(() => ({}));
        U.toast('Connected \u2713 ' + (data.service || 'server reachable'), 'ok');
        return true;
      } catch (e) {
        U.toast('Connection failed: ' + (e.message || 'error'), 'err');
        return false;
      }
    },

    async syncNow(silent) {
      const s = DB.settings();
      if (!Sync.isOnline()) { Sync.state = 'offline'; Sync.emit(); if (!silent) U.toast('No internet connection', 'warn'); return; }
      const url = Sync.endpointUrl();
      if (!url) { if (!silent) U.toast('Set a cloud server URL in Settings first', 'warn'); return; }

      Sync.state = 'syncing'; Sync.emit();
      try {
        const payload = {
          deviceId: s.deviceId,
          group: s.group || 'default',
          sentAt: new Date().toISOString(),
          since: s.lastSync || null,
          changes: {}
        };
        DB.COLLECTIONS.forEach(c => { payload.changes[c] = DB.pending(c); });

        const res = await fetch(url, { method: 'POST', headers: Sync.headers(), body: JSON.stringify(payload) });
        if (!res.ok) throw new Error('Server responded ' + res.status);
        const data = await res.json().catch(() => ({}));

        // 1) mark everything we pushed as synced
        DB.COLLECTIONS.forEach(c => {
          const ids = payload.changes[c].map(r => r.id);
          if (ids.length) DB.markSynced(c, ids);
        });

        // 2) merge everything the server sent back
        let pulled = 0;
        if (data && data.changes) {
          DB.COLLECTIONS.forEach(c => { pulled += DB.mergeRemote(c, data.changes[c]); });
        }

        DB.setSettings({ lastSync: new Date().toISOString() });
        Sync.lastPulled = pulled;
        Sync.state = 'synced'; Sync.emit();
        if (!silent) U.toast('Sync complete' + (pulled ? ' \u2022 ' + pulled + ' updated' : ''), 'ok');
        if (pulled && global.App && App.render) App.render();
      } catch (e) {
        Sync.state = 'error'; Sync.lastError = e.message || 'Sync failed'; Sync.emit();
        if (!silent) U.toast('Sync error: ' + Sync.lastError, 'err');
      }
    }
  };

  global.Sync = Sync;
})(window);
