/* ============================================================
   App controller — routing, navigation, login, shell
   ============================================================ */
(function (global) {
  'use strict';
  const { $, el, toast } = U;

  /* Bottom navigation per role */
  const NAV = {
    owner: [
      ['dashboard', 'Dashboard', '\uD83C\uDFE0'],
      ['meters', 'Meters', '\uD83D\uDD0C'],
      ['bills', 'Bills', '\uD83D\uDCC4'],
      ['reports', 'Reports', '\uD83D\uDCCA'],
      ['settings', 'Settings', '\u2699\uFE0F']
    ],
    manager: [
      ['dashboard', 'Dashboard', '\uD83C\uDFE0'],
      ['meters', 'Meters', '\uD83D\uDD0C'],
      ['bills', 'Bills', '\uD83D\uDCC4'],
      ['reports', 'Reports', '\uD83D\uDCCA'],
      ['profile', 'Profile', '\uD83D\uDC64']
    ],
    electrician: [
      ['dashboard', 'Dashboard', '\uD83C\uDFE0'],
      ['meters', 'Meters', '\uD83D\uDD0C'],
      ['readings', 'Readings', '\uD83D\uDD22'],
      ['devices', 'Load', '\uD83D\uDD0C'],
      ['profile', 'Profile', '\uD83D\uDC64']
    ]
  };

  const TITLES = {
    dashboard: ['Dashboard', 'Overview & statistics'],
    meters: ['Meters', 'Manage electricity meters'],
    meter: ['Meter Details', ''],
    readings: ['Readings', 'Unit readings'],
    bills: ['Bills', 'Manual bill entry'],
    devices: ['Load Management', 'Connected devices & load'],
    reports: ['Reports', 'Generate & export PDF reports'],
    settings: ['Settings', 'Account, users, sync & backup'],
    profile: ['Profile', 'Your account & permissions']
  };

  const App = {
    screen: 'dashboard',
    meterId: null,
    history: [],

    /* ---------------- init ---------------- */
    init() {
      DB.init();
      Auth.seedDefaults();
      Sync.init();

      // login form
      const form = $('#login-form');
      if (form) form.addEventListener('submit', (e) => { e.preventDefault(); App.doLogin(); });

      // demo chips
      U.$$('.demo-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          $('#login-user').value = chip.dataset.u;
          $('#login-pass').value = chip.dataset.p;
          App.doLogin();
        });
      });

      // back button
      const back = $('#tb-back');
      if (back) back.addEventListener('click', () => App.back());

      // FAB
      const fab = $('#fab');
      if (fab) fab.addEventListener('click', () => App.onFab());

      // sync badge updates
      Sync.on((state) => App.updateSyncBadge(state));

      // hardware back button (Android WebView)
      window.addEventListener('popstate', () => App.back());

      // restore session
      const user = Auth.restore();
      if (user) App.enterApp();
      else App.showLogin();
    },

    /* ---------------- login ---------------- */
    doLogin() {
      const username = $('#login-user').value;
      const password = $('#login-pass').value;
      const errBox = $('#login-error');
      const res = Auth.login(username, password);
      if (!res.ok) {
        errBox.textContent = res.error;
        errBox.classList.remove('hidden');
        return;
      }
      errBox.classList.add('hidden');
      $('#login-pass').value = '';
      App.enterApp();
      toast('Welcome, ' + res.user.fullName, 'ok');
    },

    showLogin() {
      $('#screen-app').classList.remove('active');
      $('#screen-login').classList.add('active');
    },

    enterApp() {
      $('#screen-login').classList.remove('active');
      $('#screen-app').classList.add('active');
      App.screen = 'dashboard';
      App.meterId = null;
      App.history = [];
      App.render();
    },

    logout() {
      U.confirmDialog('Logout', 'Are you sure you want to log out?', () => {
        Auth.logout();
        App.showLogin();
        toast('Logged out', 'ok');
      });
    },

    /* ---------------- navigation ---------------- */
    go(screen) {
      if (App.screen !== screen) App.history.push({ screen: App.screen, meterId: App.meterId });
      App.screen = screen;
      App.meterId = null;
      App.render();
      window.scrollTo(0, 0);
    },

    openMeter(id) {
      App.history.push({ screen: App.screen, meterId: App.meterId });
      App.screen = 'meter';
      App.meterId = id;
      Views.MeterDetail.tab = 'overview';
      App.render();
      window.scrollTo(0, 0);
    },

    back() {
      if (App.screen === 'meter') { App.go('meters'); return; }
      const prev = App.history.pop();
      if (prev) { App.screen = prev.screen; App.meterId = prev.meterId; App.render(); return; }
      if (App.screen !== 'dashboard') { App.go('dashboard'); return; }
      // at dashboard: exit the native app if running inside the APK
      if (window.AndroidBridge && window.AndroidBridge.exitApp) window.AndroidBridge.exitApp();
    },

    /* ---------------- FAB ---------------- */
    onFab() {
      const P = Permissions, role = Auth.current.role;
      if (App.screen === 'meters' && P.canManageMeters(role)) Views.Meters.form();
      else if (App.screen === 'readings' && P.canManageReadings(role)) Views.Readings.form();
      else if (App.screen === 'bills' && P.canManageBills(role)) Views.Bills.form();
      else if (App.screen === 'devices' && P.canManageLoad(role)) Views.Devices.form();
    },

    fabVisible() {
      const P = Permissions, role = Auth.current.role;
      if (App.screen === 'meters') return P.canManageMeters(role);
      if (App.screen === 'readings') return P.canManageReadings(role);
      if (App.screen === 'bills') return P.canManageBills(role);
      if (App.screen === 'devices') return P.canManageLoad(role);
      return false;
    },

    /* ---------------- render ---------------- */
    render() {
      if (!Auth.current) { App.showLogin(); return; }

      // topbar
      const t = TITLES[App.screen] || ['', ''];
      let title = t[0], sub = t[1];
      if (App.screen === 'meter') {
        const m = DB.get('meters', App.meterId);
        if (m) { title = m.name; sub = 'Meter ' + m.meterNumber; }
      } else if (App.screen === 'dashboard') {
        sub = Auth.roleLabel(Auth.current.role) + ' \u2022 ' + Auth.current.fullName;
      }
      $('#tb-title').textContent = title;
      $('#tb-sub').textContent = sub || '';

      // back button
      $('#tb-back').style.display = (App.screen === 'meter') ? 'flex' : 'none';

      // main view
      const view = $('#view');
      view.innerHTML = '';
      let node;
      switch (App.screen) {
        case 'dashboard': node = Views.Dashboard.render(); break;
        case 'meters': node = Views.Meters.render(); break;
        case 'meter': node = Views.MeterDetail.render(App.meterId); break;
        case 'readings': node = Views.Readings.render(); break;
        case 'bills': node = Views.Bills.render(); break;
        case 'devices': node = Views.Devices.render(); break;
        case 'reports': node = Views.Reports.render(); break;
        case 'settings': node = Views.Settings.render(); break;
        case 'profile': node = Views.Profile.render(); break;
        default: node = Views.Dashboard.render();
      }
      if (node) view.appendChild(node);

      // FAB
      const fab = $('#fab');
      if (App.fabVisible()) fab.classList.remove('hidden');
      else fab.classList.add('hidden');

      // bottom nav
      App.renderNav();

      // sync badge
      App.updateSyncBadge(Sync.state);
    },

    renderNav() {
      const nav = $('#bottom-nav');
      nav.innerHTML = '';
      const items = NAV[Auth.current.role] || NAV.electrician;
      items.forEach(it => {
        const active = (App.screen === it[0]) || (it[0] === 'meters' && App.screen === 'meter');
        const btn = el('button', { class: 'nav-item' + (active ? ' active' : ''), onclick: () => App.go(it[0]) }, [
          el('span', { class: 'n-ico', text: it[2] }),
          el('span', { class: 'n-lbl', text: it[1] })
        ]);
        nav.appendChild(btn);
      });
    },

    updateSyncBadge(state) {
      const badge = $('#sync-badge');
      const label = $('#sync-label');
      if (!badge || !label) return;
      badge.className = 'sync-badge ' + state;
      label.textContent = Sync.label();
    }
  };

  global.App = App;

  // boot
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', App.init);
  else App.init();
})(window);
