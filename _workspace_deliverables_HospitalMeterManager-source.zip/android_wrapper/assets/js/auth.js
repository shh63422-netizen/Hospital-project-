/* ============================================================
   Auth — roles, permissions, password hashing (pure-JS SHA-256)
   ============================================================ */
(function (global) {
  'use strict';

  /* ---- Minimal SHA-256 (works offline, no secure-context needed) ---- */
  function sha256(ascii) {
    function rightRotate(v, a) { return (v >>> a) | (v << (32 - a)); }
    const maxWord = Math.pow(2, 32);
    let result = '';
    const words = [];
    const asciiBitLength = ascii.length * 8;
    let hash = sha256.h = sha256.h || [];
    const k = sha256.k = sha256.k || [];
    let primeCounter = k.length;
    const isComposite = {};
    for (let candidate = 2; primeCounter < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
        hash[primeCounter] = (Math.pow(candidate, .5) * maxWord) | 0;
        k[primeCounter++] = (Math.pow(candidate, 1 / 3) * maxWord) | 0;
      }
    }
    ascii += '\x80';
    while (ascii.length % 64 - 56) ascii += '\x00';
    for (let i = 0; i < ascii.length; i++) {
      const j = ascii.charCodeAt(i);
      if (j >> 8) return '';
      words[i >> 2] |= j << ((3 - i) % 4) * 8;
    }
    words[words.length] = (asciiBitLength / maxWord) | 0;
    words[words.length] = asciiBitLength;
    for (let j = 0; j < words.length;) {
      const w = words.slice(j, j += 16);
      const oldHash = hash;
      hash = hash.slice(0, 8);
      for (let i = 0; i < 64; i++) {
        const w15 = w[i - 15], w2 = w[i - 2];
        const a = hash[0], e = hash[4];
        const temp1 = hash[7]
          + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25))
          + ((e & hash[5]) ^ ((~e) & hash[6]))
          + k[i]
          + (w[i] = (i < 16) ? w[i] : (
            w[i - 16]
            + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3))
            + w[i - 7]
            + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
          ) | 0);
        const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22))
          + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(temp1 + temp2) | 0].concat(hash);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for (let i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    for (let i = 0; i < 8; i++) {
      for (let j = 3; j + 1; j--) {
        const b = (hash[i] >> (j * 8)) & 255;
        result += ((b < 16) ? 0 : '') + b.toString(16);
      }
    }
    return result;
  }

  function genSalt() {
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
  }
  function hashPassword(salt, password) {
    return sha256(salt + '::' + password);
  }
  function verify(salt, password, hash) {
    return hashPassword(salt, password) === hash;
  }

  /* ---- Permissions ---- */
  const Permissions = {
    canManageMeters(role) { return role === 'owner' || role === 'manager'; },
    canManageBills(role) { return role === 'owner' || role === 'manager'; },
    canManageReadings(role) { return role === 'owner' || role === 'manager' || role === 'electrician'; },
    canManageLoad(role) { return role === 'owner' || role === 'manager' || role === 'electrician'; },
    canViewReports(role) { return role === 'owner' || role === 'manager'; },
    canManageUsers(role) { return role === 'owner'; },
    canBackup(role) { return role === 'owner'; },
    canSync(role) { return role === 'owner' || role === 'manager'; },
    canDelete(role) { return role === 'owner' || role === 'manager'; },
    canViewDashboard(role) { return role === 'owner' || role === 'manager'; }
  };

  /* ---- Session ---- */
  const SESSION_KEY = 'hmm_session';

  const Auth = {
    current: null,

    seedDefaults() {
      if (DB.all('users').length) return;
      const now = new Date().toISOString();
      const mk = (username, password, fullName, role, assigned) => {
        const salt = genSalt();
        return {
          id: U.uid(), username, salt, passwordHash: hashPassword(salt, password),
          fullName, role, active: true, assignedMeterIds: assigned || [],
          createdAt: now, updatedAt: now, syncStatus: 'pending', deleted: false
        };
      };
      DB.insert('users', mk('owner', 'owner123', 'Owner', 'owner', []));
      DB.insert('users', mk('manager', 'manager123', 'Manager', 'manager', []));
      DB.insert('users', mk('electrician', 'electrician123', 'Electrician', 'electrician', []));
    },

    login(username, password) {
      const u = DB.all('users').find(x => x.username.toLowerCase() === String(username).toLowerCase().trim());
      if (!u) return { ok: false, error: 'User not found' };
      if (!u.active) return { ok: false, error: 'Account is disabled' };
      if (!verify(u.salt, password, u.passwordHash)) return { ok: false, error: 'Incorrect password' };
      Auth.current = u;
      try { localStorage.setItem(SESSION_KEY, u.id); } catch (e) {}
      return { ok: true, user: u };
    },

    restore() {
      try {
        const id = localStorage.getItem(SESSION_KEY);
        if (!id) return null;
        const u = DB.get('users', id);
        if (u && u.active) { Auth.current = u; return u; }
      } catch (e) {}
      return null;
    },

    logout() {
      Auth.current = null;
      try { localStorage.removeItem(SESSION_KEY); } catch (e) {}
    },

    changePassword(userId, oldPass, newPass) {
      const u = DB.get('users', userId);
      if (!u) return { ok: false, error: 'User not found' };
      if (!verify(u.salt, oldPass, u.passwordHash)) return { ok: false, error: 'Current password is incorrect' };
      const salt = genSalt();
      DB.update('users', userId, { salt, passwordHash: hashPassword(salt, newPass), syncStatus: 'pending' });
      return { ok: true };
    },

    createUser(data) {
      const exists = DB.all('users').some(u => u.username.toLowerCase() === data.username.toLowerCase());
      if (exists) return { ok: false, error: 'Username already exists' };
      const salt = genSalt();
      const now = new Date().toISOString();
      const rec = {
        id: U.uid(), username: data.username.trim(), salt,
        passwordHash: hashPassword(salt, data.password),
        fullName: data.fullName || data.username, role: data.role,
        active: true, assignedMeterIds: data.assignedMeterIds || [],
        createdAt: now, updatedAt: now, syncStatus: 'pending', deleted: false
      };
      DB.insert('users', rec);
      return { ok: true, user: rec };
    },

    updateUser(id, patch) {
      if (patch.password) {
        const salt = genSalt();
        patch.salt = salt;
        patch.passwordHash = hashPassword(salt, patch.password);
        delete patch.password;
      }
      patch.syncStatus = 'pending';
      return DB.update('users', id, patch);
    },

    roleLabel(role) {
      return { owner: 'Owner', manager: 'Manager', electrician: 'Electrician' }[role] || role;
    }
  };

  global.Auth = Auth;
  global.Permissions = Permissions;
  global.sha256 = sha256;
})(window);
