/* ============================================================
   Backup — export / import / CSV
   ============================================================ */
(function (global) {
  'use strict';

  function download(filename, content, mime) {
    const blob = new Blob([content], { type: mime || 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function csvCell(v) {
    const s = String(v == null ? '' : v);
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function toCsv(headers, rows) {
    return [headers.join(',')].concat(rows.map(r => r.map(csvCell).join(','))).join('\n');
  }

  const Backup = {
    exportJson() {
      const data = DB.exportAll();
      download('hospital-meter-backup-' + U.Fmt.today() + '.json', JSON.stringify(data, null, 2), 'application/json');
      U.toast('Backup exported', 'ok');
    },

    importJson(file, cb) {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const obj = JSON.parse(reader.result);
          DB.importAll(obj);
          U.toast('Backup restored', 'ok');
          if (cb) cb(true);
        } catch (e) { U.toast('Invalid backup file', 'err'); if (cb) cb(false); }
      };
      reader.readAsText(file);
    },

    exportMetersCsv() {
      const meters = DB.all('meters');
      const headers = ['Meter Number', 'Customer ID', 'Name', 'Department', 'Location', 'Status', 'Start Date', 'Stop Date', 'Initial Units', 'Notes'];
      const rows = meters.map(m => [m.meterNumber, m.customerId, m.name, m.department, m.location, m.status, m.startDate, m.stopDate, m.initialUnits, m.notes]);
      download('meters-' + U.Fmt.today() + '.csv', toCsv(headers, rows), 'text/csv');
      U.toast('Meters CSV exported', 'ok');
    },

    exportReadingsCsv() {
      const meters = DB.all('meters');
      const headers = ['Date', 'Meter Number', 'Name', 'Units', 'Consumption', 'Notes'];
      const rows = DB.all('readings').map(r => {
        const m = meters.find(x => x.id === r.meterId) || {};
        return [r.date, m.meterNumber, m.name, r.units, r.consumption, r.notes];
      });
      download('readings-' + U.Fmt.today() + '.csv', toCsv(headers, rows), 'text/csv');
      U.toast('Readings CSV exported', 'ok');
    },

    exportBillsCsv() {
      const meters = DB.all('meters');
      const headers = ['Billing Month', 'Meter Number', 'Name', 'Bill Date', 'Due Date', 'Bill Amount', 'Paid Amount', 'Outstanding', 'Payment Date', 'Status', 'Reference'];
      const rows = DB.all('bills').map(b => {
        const m = meters.find(x => x.id === b.meterId) || {};
        return [b.billingMonth, m.meterNumber, m.name, b.billDate, b.dueDate, b.billAmount, b.paidAmount, b.outstanding, b.paymentDate, b.paymentStatus, b.reference];
      });
      download('bills-' + U.Fmt.today() + '.csv', toCsv(headers, rows), 'text/csv');
      U.toast('Bills CSV exported', 'ok');
    },

    exportFullCsv() {
      Backup.exportMetersCsv();
      setTimeout(Backup.exportReadingsCsv, 400);
      setTimeout(Backup.exportBillsCsv, 800);
    }
  };

  global.Backup = Backup;
})(window);
