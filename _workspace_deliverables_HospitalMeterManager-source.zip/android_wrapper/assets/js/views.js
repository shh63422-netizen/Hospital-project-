/* ============================================================
   Views — all screens
   ============================================================ */
(function (global) {
  'use strict';
  const { el, Fmt, esc, toast, openSheet, confirmDialog } = U;

  /* ---------- Load helper ---------- */
  const Load = {
    totalKw(meterId) {
      return DB.all('devices').filter(d => d.meterId === meterId)
        .reduce((s, d) => s + Number(d.effectiveKw || 0), 0);
    },
    totalKwAll() {
      return DB.all('devices').reduce((s, d) => s + Number(d.effectiveKw || 0), 0);
    }
  };
  global.Load = Load;

  /* ---------- shared builders ---------- */
  function statCard(cls, ico, val, lbl) {
    return el('div', { class: 'stat ' + cls }, [
      el('div', { class: 's-ico', text: ico }),
      el('div', { class: 's-val', text: val }),
      el('div', { class: 's-lbl', text: lbl })
    ]);
  }
  function statusBadge(status) {
    const map = { Active: 'green', Stopped: 'grey', Faulty: 'red', Removed: 'grey' };
    return el('span', { class: 'badge ' + (map[status] || 'grey'), text: status });
  }
  function payBadge(s) {
    const map = { Paid: 'green', 'Partially Paid': 'amber', Unpaid: 'red' };
    return el('span', { class: 'badge ' + (map[s] || 'grey'), text: s });
  }
  function meterById(id) { return DB.get('meters', id); }
  function meterLabel(id) { const m = meterById(id); return m ? (m.meterNumber + ' — ' + m.name) : 'Unknown meter'; }

  function field(label, input, req) {
    return el('div', { class: 'field' }, [
      el('label', { html: esc(label) + (req ? ' <span class="req">*</span>' : '') }),
      input
    ]);
  }
  function inputEl(id, type, val, ph) {
    return el('input', { class: 'input', id, type: type || 'text', value: val == null ? '' : val, placeholder: ph || '' });
  }
  function selectEl(id, options, val) {
    const s = el('select', { class: 'select', id });
    options.forEach(o => {
      const opt = el('option', { value: o, text: o });
      if (o === val) opt.selected = true;
      s.appendChild(opt);
    });
    return s;
  }

  /* ============================================================
     DASHBOARD
     ============================================================ */
  const Dashboard = {
    filter: { from: '', to: '' },

    render() {
      const meters = DB.all('meters');
      const readings = DB.all('readings');
      const bills = DB.all('bills');
      const thisMonth = Fmt.monthKey(new Date());
      const lastMonthDate = new Date(); lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
      const lastMonth = Fmt.monthKey(lastMonthDate);

      const inRange = (d) => Fmt.inRange(d, Dashboard.filter.from, Dashboard.filter.to);

      const total = meters.length;
      const active = meters.filter(m => m.status === 'Active').length;
      const stopped = meters.filter(m => m.status === 'Stopped').length;

      const monthReadings = readings.filter(r => Fmt.monthKey(r.date) === thisMonth);
      const thisMonthUnits = monthReadings.reduce((s, r) => s + Number(r.consumption || 0), 0);

      const thisMonthBills = bills.filter(b => b.billingMonth === thisMonth);
      const thisMonthBill = thisMonthBills.reduce((s, b) => s + Number(b.billAmount || 0), 0);
      const lastMonthBills = bills.filter(b => b.billingMonth === lastMonth);
      const lastMonthBill = lastMonthBills.reduce((s, b) => s + Number(b.billAmount || 0), 0);

      const totalPaid = bills.reduce((s, b) => s + Number(b.paidAmount || 0), 0);
      const totalOutstanding = bills.reduce((s, b) => s + Number(b.outstanding || 0), 0);
      const totalLoad = Load.totalKwAll();

      const wrap = el('div');

      // date filter
      const filterCard = el('div', { class: 'card' }, [
        el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '📅' }), 'Date Filter']),
        el('div', { class: 'field-row' }, [
          field('From', inputEl('dash-from', 'date', Dashboard.filter.from)),
          field('To', inputEl('dash-to', 'date', Dashboard.filter.to))
        ]),
        el('div', { class: 'row' }, [
          el('button', { class: 'btn btn-primary btn-sm', text: 'Apply', onclick: () => {
            Dashboard.filter.from = U.$('#dash-from').value;
            Dashboard.filter.to = U.$('#dash-to').value;
            App.render();
          }}),
          el('button', { class: 'btn btn-ghost btn-sm', text: 'Clear', onclick: () => {
            Dashboard.filter = { from: '', to: '' }; App.render();
          }})
        ])
      ]);
      wrap.appendChild(filterCard);

      const grid = el('div', { class: 'stat-grid' });
      grid.appendChild(statCard('green', '🔢', total, 'Total Meters'));
      grid.appendChild(statCard('green', '✅', active, 'Active Meters'));
      grid.appendChild(statCard('red', '⛔', stopped, 'Stopped Meters'));
      grid.appendChild(statCard('blue', '⚡', Fmt.number(thisMonthUnits, 2), 'This Month Units'));
      grid.appendChild(statCard('blue', '🧾', Fmt.money(thisMonthBill), 'This Month Bill'));
      grid.appendChild(statCard('amber', '📄', Fmt.money(lastMonthBill), 'Last Month Bill'));
      grid.appendChild(statCard('green', '💰', Fmt.money(totalPaid), 'Total Paid'));
      grid.appendChild(statCard('red', '⚠️', Fmt.money(totalOutstanding), 'Total Outstanding'));
      grid.appendChild(statCard('purple', '🔌', Fmt.number(totalLoad, 2) + ' kW', 'Total Connected Load'));
      wrap.appendChild(grid);

      // recent readings
      const recent = readings.slice().sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 5);
      if (recent.length) {
        const card = el('div', { class: 'card mt16' }, [el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '🕒' }), 'Recent Readings'])]);
        recent.forEach(r => {
          card.appendChild(el('div', { class: 'list-item' }, [
            el('div', { class: 'li-body' }, [
              el('div', { class: 'li-title', text: meterLabel(r.meterId) }),
              el('div', { class: 'li-sub', text: Fmt.date(r.date) })
            ]),
            el('div', { class: 'li-right', text: Fmt.number(r.consumption, 2) + ' kWh' })
          ]));
        });
        wrap.appendChild(card);
      }

      wrap.appendChild(el('div', { class: 'branding', html: 'Software Developed By <b>Tech Arslan Software Solutions</b><br>03200199895' }));
      return wrap;
    }
  };

  /* ============================================================
     METERS
     ============================================================ */
  const Meters = {
    query: '',

    render() {
      const wrap = el('div');
      const search = el('div', { class: 'searchbar' }, [
        el('span', { class: 's-ico', text: '🔍' }),
        el('input', { type: 'text', placeholder: 'Search meter no, customer, name, dept, location', value: Meters.query,
          oninput: (e) => { Meters.query = e.target.value; App.render(); } })
      ]);
      wrap.appendChild(search);

      let list = DB.all('meters');
      const q = Meters.query.toLowerCase().trim();
      if (q) {
        list = list.filter(m => [m.meterNumber, m.customerId, m.name, m.department, m.location]
          .some(v => String(v || '').toLowerCase().includes(q)));
      }
      list.sort((a, b) => (a.meterNumber || '').localeCompare(b.meterNumber || ''));

      if (!list.length) {
        wrap.appendChild(el('div', { class: 'empty' }, [
          el('div', { class: 'e-ico', text: '🔌' }),
          el('h3', { text: q ? 'No meters found' : 'No meters yet' }),
          el('p', { text: q ? 'Try a different search' : 'Tap + to add your first meter' })
        ]));
        return wrap;
      }

      list.forEach(m => {
        const card = el('div', { class: 'meter-card', onclick: () => App.openMeter(m.id) }, [
          el('div', { class: 'mc-avatar', text: '⚡' }),
          el('div', { class: 'mc-body' }, [
            el('div', { class: 'mc-name', text: m.name }),
            el('div', { class: 'mc-meta', text: 'Meter ' + m.meterNumber + (m.customerId ? ' • Cust ' + m.customerId : '') }),
            el('div', { class: 'mc-meta', text: (m.department || '—') + ' • ' + (m.location || '—') }),
            el('div', { class: 'mc-tags' }, [statusBadge(m.status), el('span', { class: 'badge blue', text: Fmt.number(Load.totalKw(m.id), 2) + ' kW' })])
          ])
        ]);
        wrap.appendChild(card);
      });
      return wrap;
    },

    form(meterId) {
      const m = meterId ? DB.get('meters', meterId) : null;
      const isEdit = !!m;
      const content = el('div');
      content.appendChild(field('Meter Number', inputEl('f-meterNumber', 'text', m ? m.meterNumber : ''), true));
      content.appendChild(field('Customer ID', inputEl('f-customerId', 'text', m ? m.customerId : '')));
      content.appendChild(field('Name / Department', inputEl('f-name', 'text', m ? m.name : ''), true));
      content.appendChild(field('Department', inputEl('f-department', 'text', m ? m.department : '')));
      content.appendChild(field('Location', inputEl('f-location', 'text', m ? m.location : '')));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Start Date', inputEl('f-startDate', 'date', m ? m.startDate : Fmt.today())),
        field('Stop Date', inputEl('f-stopDate', 'date', m ? m.stopDate : ''))
      ]));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Status', selectEl('f-status', U.METER_STATUS, m ? m.status : 'Active')),
        field('Initial Units', inputEl('f-initialUnits', 'number', m ? m.initialUnits : 0))
      ]));
      content.appendChild(field('Notes', el('textarea', { class: 'textarea', id: 'f-notes' }, [m ? m.notes || '' : ''])));

      const sheet = openSheet({ title: isEdit ? 'Edit Meter' : 'Add Meter', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', style: 'flex:1', onclick: () => sheet.close() }),
        el('button', { class: 'btn btn-primary', text: isEdit ? 'Save' : 'Add Meter', style: 'flex:1', onclick: () => {
          const data = {
            meterNumber: U.$('#f-meterNumber').value.trim(),
            customerId: U.$('#f-customerId').value.trim(),
            name: U.$('#f-name').value.trim(),
            department: U.$('#f-department').value.trim(),
            location: U.$('#f-location').value.trim(),
            startDate: U.$('#f-startDate').value,
            stopDate: U.$('#f-stopDate').value,
            status: U.$('#f-status').value,
            initialUnits: Number(U.$('#f-initialUnits').value || 0),
            notes: U.$('#f-notes').value.trim()
          };
          if (!data.meterNumber || !data.name) { toast('Meter number and name are required', 'err'); return; }
          if (isEdit) { DB.update('meters', meterId, Object.assign(data, { syncStatus: 'pending' })); toast('Meter updated', 'ok'); }
          else {
            const now = new Date().toISOString();
            DB.insert('meters', Object.assign({ id: U.uid(), createdAt: now, updatedAt: now, syncStatus: 'pending', deleted: false }, data));
            toast('Meter added', 'ok');
          }
          sheet.close(); App.render();
        }})
      ]));
    }
  };

  /* ============================================================
     METER DETAIL (tabs)
     ============================================================ */
  const MeterDetail = {
    tab: 'overview',

    render(meterId) {
      const m = DB.get('meters', meterId);
      if (!m) return el('div', { class: 'empty' }, [el('p', { text: 'Meter not found' })]);
      const wrap = el('div');

      const head = el('div', { class: 'card' }, [
        el('div', { class: 'row' }, [
          el('div', { class: 'mc-avatar', text: '⚡' }),
          el('div', { style: 'flex:1' }, [
            el('div', { class: 'mc-name', text: m.name }),
            el('div', { class: 'mc-meta', text: 'Meter ' + m.meterNumber })
          ]),
          statusBadge(m.status)
        ]),
        el('div', { class: 'row mt12' }, [
          el('button', { class: 'btn btn-soft btn-sm', text: '✏️ Edit', onclick: () => Meters.form(m.id) }),
          el('button', { class: 'btn btn-ghost btn-sm', text: '📄 PDF', onclick: () => {
            const doc = Pdf.singleMeterSummary(m, DB.all('readings').filter(r => r.meterId === m.id),
              DB.all('bills').filter(b => b.meterId === m.id), DB.all('devices').filter(d => d.meterId === m.id));
            Pdf.save(doc, 'meter-' + m.meterNumber + '.pdf');
          }}),
          Permissions.canDelete(Auth.current.role) ? el('button', { class: 'btn btn-ghost btn-sm', text: '🗑️', onclick: () => {
            confirmDialog('Delete Meter', 'Delete this meter and all its data?', () => {
              DB.remove('meters', m.id); toast('Meter deleted', 'ok'); App.go('meters');
            });
          }}) : null
        ])
      ]);
      wrap.appendChild(head);

      const tabs = ['overview', 'units', 'bills', 'load', 'history', 'summary'];
      const tabBar = el('div', { class: 'tabs' });
      tabs.forEach(t => tabBar.appendChild(el('button', { class: 'tab' + (MeterDetail.tab === t ? ' active' : ''), text: t.charAt(0).toUpperCase() + t.slice(1),
        onclick: () => { MeterDetail.tab = t; App.render(); } })));
      wrap.appendChild(tabBar);

      const body = el('div');
      if (MeterDetail.tab === 'overview') body.appendChild(MeterDetail.overview(m));
      else if (MeterDetail.tab === 'units') body.appendChild(MeterDetail.units(m));
      else if (MeterDetail.tab === 'bills') body.appendChild(MeterDetail.bills(m));
      else if (MeterDetail.tab === 'load') body.appendChild(MeterDetail.load(m));
      else if (MeterDetail.tab === 'history') body.appendChild(MeterDetail.history(m));
      else body.appendChild(MeterDetail.summary(m));
      wrap.appendChild(body);
      return wrap;
    },

    overview(m) {
      const card = el('div', { class: 'card' });
      const rows = [
        ['Meter Number', m.meterNumber], ['Customer ID', m.customerId || '—'],
        ['Name / Department', m.name], ['Department', m.department || '—'],
        ['Location', m.location || '—'], ['Status', m.status],
        ['Start Date', Fmt.date(m.startDate)], ['Stop Date', m.stopDate ? Fmt.date(m.stopDate) : '—'],
        ['Initial Units', Fmt.number(m.initialUnits, 2)], ['Connected Load', Fmt.number(Load.totalKw(m.id), 2) + ' kW'],
        ['Notes', m.notes || '—']
      ];
      rows.forEach(r => card.appendChild(el('div', { class: 'kv' }, [el('span', { class: 'k', text: r[0] }), el('span', { class: 'v', text: String(r[1]) })])));
      return card;
    },

    units(m) {
      const card = el('div', { class: 'card' });
      card.appendChild(el('div', { class: 'section-head' }, [
        el('h2', { text: 'Unit Readings' }),
        Permissions.canManageReadings(Auth.current.role) ? el('button', { class: 'btn btn-primary btn-sm', text: '+ Add', onclick: () => Readings.form(m.id) }) : null
      ]));
      const list = DB.all('readings').filter(r => r.meterId === m.id).sort((a, b) => (a.date < b.date ? 1 : -1));
      if (!list.length) { card.appendChild(el('div', { class: 'empty' }, [el('p', { text: 'No readings yet' })])); return card; }
      const t = el('table', { class: 'data-table' });
      t.appendChild(el('tr', {}, [el('th', { text: 'Date' }), el('th', { class: 'num', text: 'Units' }), el('th', { class: 'num', text: 'Consumption' }), el('th', { text: '' })]));
      list.forEach(r => {
        const tr = el('tr', {}, [
          el('td', { text: Fmt.date(r.date) }),
          el('td', { class: 'num', text: Fmt.number(r.units, 2) }),
          el('td', { class: 'num', text: Fmt.number(r.consumption, 2) }),
          el('td', {}, [el('button', { class: 'btn btn-ghost btn-sm', text: '⋯', onclick: () => Readings.actions(r) })])
        ]);
        t.appendChild(tr);
      });
      card.appendChild(t);
      return card;
    },

    bills(m) {
      const card = el('div', { class: 'card' });
      card.appendChild(el('div', { class: 'section-head' }, [
        el('h2', { text: 'Bills' }),
        Permissions.canManageBills(Auth.current.role) ? el('button', { class: 'btn btn-primary btn-sm', text: '+ Add', onclick: () => Bills.form(m.id) }) : null
      ]));
      const list = DB.all('bills').filter(b => b.meterId === m.id).sort((a, b) => (a.billingMonth < b.billingMonth ? 1 : -1));
      if (!list.length) { card.appendChild(el('div', { class: 'empty' }, [el('p', { text: 'No bills yet' })])); return card; }
      list.forEach(b => {
        card.appendChild(el('div', { class: 'list-item' }, [
          el('div', { class: 'li-body' }, [
            el('div', { class: 'li-title', text: Fmt.monthLabel(b.billingMonth) }),
            el('div', { class: 'li-sub', text: 'Bill ' + Fmt.money(b.billAmount) + ' • Paid ' + Fmt.money(b.paidAmount) })
          ]),
          el('div', { class: 'li-right' }, [payBadge(b.paymentStatus), el('small', { text: 'Due ' + Fmt.money(b.outstanding) })])
        ]));
      });
      return card;
    },

    load(m) {
      const card = el('div', { class: 'card' });
      card.appendChild(el('div', { class: 'section-head' }, [
        el('h2', { text: 'Connected Load' }),
        Permissions.canManageLoad(Auth.current.role) ? el('button', { class: 'btn btn-primary btn-sm', text: '+ Add', onclick: () => Devices.form(m.id) }) : null
      ]));
      const list = DB.all('devices').filter(d => d.meterId === m.id);
      card.appendChild(el('div', { class: 'alert info', text: 'Total Connected Load: ' + Fmt.number(Load.totalKw(m.id), 3) + ' kW' }));
      if (!list.length) { card.appendChild(el('div', { class: 'empty' }, [el('p', { text: 'No devices yet' })])); return card; }
      list.forEach(d => {
        card.appendChild(el('div', { class: 'list-item' }, [
          el('div', { class: 'li-body' }, [
            el('div', { class: 'li-title', text: d.name + ' × ' + d.quantity }),
            el('div', { class: 'li-sub', text: d.category + ' • ' + Fmt.number(d.voltage, 0) + 'V ' + Fmt.number(d.ampere, 2) + 'A' })
          ]),
          el('div', { class: 'li-right' }, [Fmt.number(d.effectiveKw, 3) + ' kW', el('small', { text: 'tap to edit', onclick: () => Devices.form(m.id, d.id) })])
        ]));
      });
      return card;
    },

    history(m) {
      const card = el('div', { class: 'card' });
      card.appendChild(el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '📜' }), 'History']));
      const events = [];
      DB.all('readings').filter(r => r.meterId === m.id).forEach(r => events.push({ t: r.createdAt, txt: 'Reading ' + Fmt.number(r.units, 2) + ' on ' + Fmt.date(r.date) }));
      DB.all('bills').filter(b => b.meterId === m.id).forEach(b => events.push({ t: b.createdAt, txt: 'Bill ' + Fmt.money(b.billAmount) + ' for ' + Fmt.monthLabel(b.billingMonth) }));
      DB.all('devices').filter(d => d.meterId === m.id).forEach(d => events.push({ t: d.createdAt, txt: 'Device added: ' + d.name }));
      events.push({ t: m.createdAt, txt: 'Meter created' });
      events.sort((a, b) => (a.t < b.t ? 1 : -1));
      if (!events.length) card.appendChild(el('div', { class: 'empty' }, [el('p', { text: 'No history' })]));
      events.forEach(e => card.appendChild(el('div', { class: 'list-item' }, [
        el('div', { class: 'li-body' }, [el('div', { class: 'li-title', text: e.txt }), el('div', { class: 'li-sub', text: Fmt.dateTime(e.t) })])
      ])));
      return card;
    },

    summary(m) {
      const readings = DB.all('readings').filter(r => r.meterId === m.id);
      const bills = DB.all('bills').filter(b => b.meterId === m.id);
      const totalUnits = readings.reduce((s, r) => s + Number(r.consumption || 0), 0);
      const totalBill = bills.reduce((s, b) => s + Number(b.billAmount || 0), 0);
      const totalPaid = bills.reduce((s, b) => s + Number(b.paidAmount || 0), 0);
      const totalOut = bills.reduce((s, b) => s + Number(b.outstanding || 0), 0);
      const card = el('div', { class: 'card' });
      card.appendChild(el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '📊' }), 'Summary']));
      [['Total Readings', readings.length], ['Total Units', Fmt.number(totalUnits, 2)],
       ['Total Bill', Fmt.money(totalBill)], ['Total Paid', Fmt.money(totalPaid)],
       ['Total Outstanding', Fmt.money(totalOut)], ['Connected Load', Fmt.number(Load.totalKw(m.id), 3) + ' kW']]
        .forEach(r => card.appendChild(el('div', { class: 'kv' }, [el('span', { class: 'k', text: r[0] }), el('span', { class: 'v', text: String(r[1]) })])));
      return card;
    }
  };

  /* ============================================================
     READINGS
     ============================================================ */
  const Readings = {
    query: '',

    render() {
      const wrap = el('div');
      const search = el('div', { class: 'searchbar' }, [
        el('span', { class: 's-ico', text: '\uD83D\uDD0D' }),
        el('input', { type: 'text', placeholder: 'Search by meter or date', value: Readings.query,
          oninput: (e) => { Readings.query = e.target.value; App.render(); } })
      ]);
      wrap.appendChild(search);

      let list = DB.all('readings').slice();
      const q = (Readings.query || '').toLowerCase().trim();
      if (q) list = list.filter(r => (meterLabel(r.meterId) + ' ' + r.date).toLowerCase().includes(q));
      list.sort((a, b) => (a.date < b.date ? 1 : -1));

      if (!list.length) {
        wrap.appendChild(el('div', { class: 'empty' }, [
          el('div', { class: 'e-ico', text: '\uD83D\uDD22' }),
          el('h3', { text: q ? 'No readings found' : 'No readings yet' }),
          el('p', { text: q ? 'Try a different search' : 'Tap + to add a unit reading' })
        ]));
        return wrap;
      }

      const card = el('div', { class: 'card' });
      list.forEach(r => card.appendChild(el('div', { class: 'list-item', onclick: () => Readings.actions(r) }, [
        el('div', { class: 'li-body' }, [
          el('div', { class: 'li-title', text: meterLabel(r.meterId) }),
          el('div', { class: 'li-sub', text: Fmt.date(r.date) + ' \u2022 ' + Fmt.number(r.units, 2) + ' kWh' })
        ]),
        el('div', { class: 'li-right', text: '+' + Fmt.number(r.consumption, 2) })
      ])));
      wrap.appendChild(card);
      return wrap;
    },

    form(meterId, readingId) {
      const r = readingId ? DB.get('readings', readingId) : null;
      const content = el('div');
      const meters = DB.all('meters');
      const meterSel = el('select', { class: 'select', id: 'r-meter' });
      meters.forEach(m => { const o = el('option', { value: m.id, text: m.meterNumber + ' — ' + m.name }); if (m.id === meterId) o.selected = true; meterSel.appendChild(o); });
      content.appendChild(field('Meter', meterSel, true));
      content.appendChild(field('Reading Date', inputEl('r-date', 'date', r ? r.date : Fmt.today()), true));
      content.appendChild(field('Meter Units (kWh)', inputEl('r-units', 'number', r ? r.units : ''), true));
      content.appendChild(field('Notes', el('textarea', { class: 'textarea', id: 'r-notes' }, [r ? r.notes || '' : ''])));
      content.appendChild(el('div', { class: 'hint', text: 'Consumption is calculated from the previous reading. Previous readings are never overwritten.' }));

      const sheet = openSheet({ title: r ? 'Edit Reading' : 'Add Reading', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', style: 'flex:1', onclick: () => sheet.close() }),
        el('button', { class: 'btn btn-primary', text: 'Save', style: 'flex:1', onclick: () => {
          const mid = U.$('#r-meter').value;
          const date = U.$('#r-date').value;
          const units = Number(U.$('#r-units').value);
          if (!date || isNaN(units)) { toast('Date and units are required', 'err'); return; }
          const prev = DB.all('readings').filter(x => x.meterId === mid && x.id !== (r ? r.id : '') && x.date < date)
            .sort((a, b) => (a.date < b.date ? 1 : -1))[0];
          const meter = DB.get('meters', mid);
          const base = prev ? Number(prev.units) : Number(meter ? meter.initialUnits : 0);
          const consumption = Math.max(0, units - base);
          const now = new Date().toISOString();
          if (r) DB.update('readings', r.id, { meterId: mid, date, units, consumption, notes: U.$('#r-notes').value.trim(), syncStatus: 'pending' });
          else DB.insert('readings', { id: U.uid(), meterId: mid, date, units, consumption, notes: U.$('#r-notes').value.trim(), createdAt: now, updatedAt: now, syncStatus: 'pending', deleted: false });
          toast('Reading saved', 'ok'); sheet.close(); App.render();
        }})
      ]));
    },

    actions(r) {
      const content = el('div');
      content.appendChild(el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Date' }), el('span', { class: 'v', text: Fmt.date(r.date) })]));
      content.appendChild(el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Units' }), el('span', { class: 'v', text: Fmt.number(r.units, 2) })]));
      content.appendChild(el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Consumption' }), el('span', { class: 'v', text: Fmt.number(r.consumption, 2) })]));
      const sheet = openSheet({ title: 'Reading', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-soft', text: '✏️ Edit', style: 'flex:1', onclick: () => { sheet.close(); Readings.form(r.meterId, r.id); } }),
        el('button', { class: 'btn btn-danger', text: '🗑️ Delete', style: 'flex:1', onclick: () => { sheet.close(); confirmDialog('Delete Reading', 'Delete this reading?', () => { DB.remove('readings', r.id); toast('Deleted', 'ok'); App.render(); }); } })
      ]));
    }
  };

  /* ============================================================
     BILLS
     ============================================================ */
  const Bills = {
    query: '',

    render() {
      const wrap = el('div');
      const search = el('div', { class: 'searchbar' }, [
        el('span', { class: 's-ico', text: '\uD83D\uDD0D' }),
        el('input', { type: 'text', placeholder: 'Search by meter or month', value: Bills.query,
          oninput: (e) => { Bills.query = e.target.value; App.render(); } })
      ]);
      wrap.appendChild(search);

      let list = DB.all('bills').slice();
      const q = (Bills.query || '').toLowerCase().trim();
      if (q) list = list.filter(b => (meterLabel(b.meterId) + ' ' + (b.billingMonth || '')).toLowerCase().includes(q));
      list.sort((a, b) => ((a.billingMonth || '') < (b.billingMonth || '') ? 1 : -1));

      if (!list.length) {
        wrap.appendChild(el('div', { class: 'empty' }, [
          el('div', { class: 'e-ico', text: '\uD83D\uDCC4' }),
          el('h3', { text: q ? 'No bills found' : 'No bills yet' }),
          el('p', { text: q ? 'Try a different search' : 'Tap + to add a bill' })
        ]));
        return wrap;
      }

      const card = el('div', { class: 'card' });
      list.forEach(b => card.appendChild(el('div', { class: 'list-item', onclick: () => Bills.actions(b) }, [
        el('div', { class: 'li-body' }, [
          el('div', { class: 'li-title', text: meterLabel(b.meterId) }),
          el('div', { class: 'li-sub' }, [payBadge(b.paymentStatus), el('span', { text: ' ' + (b.billingMonth || '') })]),
          el('div', { class: 'li-sub', text: 'Outstanding: ' + Fmt.money(b.outstanding) })
        ]),
        el('div', { class: 'li-right', text: Fmt.money(b.billAmount) })
      ])));
      wrap.appendChild(card);
      return wrap;
    },

    actions(b) {
      const content = el('div');
      const rows = [
        ['Meter', meterLabel(b.meterId)],
        ['Billing Month', b.billingMonth || '\u2014'],
        ['Bill Amount', Fmt.money(b.billAmount)],
        ['Paid Amount', Fmt.money(b.paidAmount)],
        ['Outstanding', Fmt.money(b.outstanding)],
        ['Payment Status', b.paymentStatus],
        ['Bill Date', b.billDate ? Fmt.date(b.billDate) : '\u2014'],
        ['Due Date', b.dueDate ? Fmt.date(b.dueDate) : '\u2014'],
        ['Reference', b.reference || '\u2014']
      ];
      rows.forEach(r => content.appendChild(el('div', { class: 'kv' }, [
        el('span', { class: 'k', text: r[0] }), el('span', { class: 'v', text: String(r[1]) })
      ])));
      const sheet = openSheet({ title: 'Bill', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-soft', text: '\u270F\uFE0F Edit', style: 'flex:1', onclick: () => { sheet.close(); Bills.form(b.meterId, b.id); } }),
        el('button', { class: 'btn btn-danger', text: '\uD83D\uDDD1\uFE0F Delete', style: 'flex:1', onclick: () => { sheet.close(); confirmDialog('Delete Bill', 'Delete this bill?', () => { DB.remove('bills', b.id); toast('Deleted', 'ok'); App.render(); }); } })
      ]));
    },

    form(meterId, billId) {
      const b = billId ? DB.get('bills', billId) : null;
      const content = el('div');
      const meters = DB.all('meters');
      const meterSel = el('select', { class: 'select', id: 'b-meter' });
      meters.forEach(m => { const o = el('option', { value: m.id, text: m.meterNumber + ' — ' + m.name }); if (m.id === meterId) o.selected = true; meterSel.appendChild(o); });
      content.appendChild(field('Meter', meterSel, true));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Billing Month', inputEl('b-month', 'month', b ? b.billingMonth : Fmt.monthKey(new Date())), true),
        field('Bill Date', inputEl('b-billDate', 'date', b ? b.billDate : Fmt.today()))
      ]));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Due Date', inputEl('b-dueDate', 'date', b ? b.dueDate : '')),
        field('Bill Amount', inputEl('b-amount', 'number', b ? b.billAmount : ''), true)
      ]));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Paid Amount', inputEl('b-paid', 'number', b ? b.paidAmount : 0)),
        field('Payment Date', inputEl('b-payDate', 'date', b ? b.paymentDate : ''))
      ]));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Payment Status', selectEl('b-status', U.PAY_STATUS, b ? b.paymentStatus : 'Unpaid')),
        field('Bill Reference', inputEl('b-ref', 'text', b ? b.reference : ''))
      ]));
      content.appendChild(field('Notes', el('textarea', { class: 'textarea', id: 'b-notes' }, [b ? b.notes || '' : ''])));
      content.appendChild(el('div', { class: 'hint', text: 'Bill amount is entered manually. Outstanding = Bill Amount − Paid Amount.' }));

      const sheet = openSheet({ title: b ? 'Edit Bill' : 'Add Bill', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', style: 'flex:1', onclick: () => sheet.close() }),
        el('button', { class: 'btn btn-primary', text: 'Save', style: 'flex:1', onclick: () => {
          const amount = Number(U.$('#b-amount').value);
          const paid = Number(U.$('#b-paid').value || 0);
          if (isNaN(amount)) { toast('Bill amount is required', 'err'); return; }
          const outstanding = Math.max(0, amount - paid);
          let status = U.$('#b-status').value;
          if (paid <= 0) status = 'Unpaid'; else if (paid >= amount) status = 'Paid'; else status = 'Partially Paid';
          const data = {
            meterId: U.$('#b-meter').value, billingMonth: U.$('#b-month').value,
            billDate: U.$('#b-billDate').value, dueDate: U.$('#b-dueDate').value,
            billAmount: amount, paidAmount: paid, outstanding, paymentDate: U.$('#b-payDate').value,
            paymentStatus: status, reference: U.$('#b-ref').value.trim(), notes: U.$('#b-notes').value.trim()
          };
          const now = new Date().toISOString();
          if (b) DB.update('bills', b.id, Object.assign(data, { syncStatus: 'pending' }));
          else DB.insert('bills', Object.assign({ id: U.uid(), createdAt: now, updatedAt: now, syncStatus: 'pending', deleted: false }, data));
          toast('Bill saved', 'ok'); sheet.close(); App.render();
        }})
      ]));
    }
  };

  /* ============================================================
     DEVICES / LOAD
     ============================================================ */
  const Devices = {
    form(meterId, deviceId) {
      const d = deviceId ? DB.get('devices', deviceId) : null;
      const content = el('div');
      const meters = DB.all('meters');
      const meterSel = el('select', { class: 'select', id: 'd-meter' });
      meters.forEach(m => { const o = el('option', { value: m.id, text: m.meterNumber + ' — ' + m.name }); if (m.id === meterId) o.selected = true; meterSel.appendChild(o); });
      content.appendChild(field('Meter', meterSel, true));
      content.appendChild(field('Device Name', inputEl('d-name', 'text', d ? d.name : ''), true));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Category', selectEl('d-category', U.DEVICE_CATEGORIES, d ? d.category : 'Lighting')),
        field('Quantity', inputEl('d-qty', 'number', d ? d.quantity : 1))
      ]));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Voltage (V)', inputEl('d-voltage', 'number', d ? d.voltage : 220)),
        field('Ampere (A)', inputEl('d-ampere', 'number', d ? d.ampere : ''))
      ]));
      content.appendChild(el('div', { class: 'field-row' }, [
        field('Watts (W)', inputEl('d-watts', 'number', d ? d.watts : '')),
        field('kW (per unit)', inputEl('d-kw', 'number', d ? d.kw : ''))
      ]));
      content.appendChild(field('Notes', el('textarea', { class: 'textarea', id: 'd-notes' }, [d ? d.notes || '' : ''])));
      content.appendChild(el('div', { class: 'hint', text: 'Estimated load = kW × quantity. If kW is blank it is derived from Watts or Voltage × Ampere.' }));

      const sheet = openSheet({ title: d ? 'Edit Device' : 'Add Device', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', style: 'flex:1', onclick: () => sheet.close() }),
        el('button', { class: 'btn btn-primary', text: 'Save', style: 'flex:1', onclick: () => {
          const qty = Number(U.$('#d-qty').value || 1);
          const voltage = Number(U.$('#d-voltage').value || 0);
          const ampere = Number(U.$('#d-ampere').value || 0);
          let watts = Number(U.$('#d-watts').value || 0);
          let kw = Number(U.$('#d-kw').value || 0);
          if (!kw && watts) kw = watts / 1000;
          if (!kw && voltage && ampere) kw = (voltage * ampere) / 1000;
          const effectiveKw = kw * qty;
          const data = {
            meterId: U.$('#d-meter').value, name: U.$('#d-name').value.trim(),
            category: U.$('#d-category').value, quantity: qty, voltage, ampere, watts, kw, effectiveKw,
            notes: U.$('#d-notes').value.trim()
          };
          if (!data.name) { toast('Device name is required', 'err'); return; }
          const now = new Date().toISOString();
          if (d) DB.update('devices', d.id, Object.assign(data, { syncStatus: 'pending' }));
          else DB.insert('devices', Object.assign({ id: U.uid(), createdAt: now, updatedAt: now, syncStatus: 'pending', deleted: false }, data));
          toast('Device saved', 'ok'); sheet.close(); App.render();
        }})
      ]));
    },

    render() {
      const wrap = el('div');
      const card = el('div', { class: 'card' }, [
        el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '🔌' }), 'Load Management']),
        el('div', { class: 'alert info', text: 'Total Connected Load: ' + Fmt.number(Load.totalKwAll(), 3) + ' kW' })
      ]);
      const list = DB.all('devices');
      if (!list.length) card.appendChild(el('div', { class: 'empty' }, [el('p', { text: 'No devices yet. Add from a meter.' })]));
      list.forEach(d => {
        card.appendChild(el('div', { class: 'list-item' }, [
          el('div', { class: 'li-body' }, [
            el('div', { class: 'li-title', text: d.name + ' × ' + d.quantity }),
            el('div', { class: 'li-sub', text: meterLabel(d.meterId) + ' • ' + d.category })
          ]),
          el('div', { class: 'li-right' }, [Fmt.number(d.effectiveKw, 3) + ' kW'])
        ]));
      });
      wrap.appendChild(card);
      return wrap;
    }
  };

  /* ============================================================
     REPORTS
     ============================================================ */
  const Reports = {
    render() {
      const wrap = el('div');
      const card = el('div', { class: 'card' }, [el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '📊' }), 'Reports'])]);
      const items = [
        { t: 'All Meters Summary', d: 'Overview of every meter with load and totals', ico: '📋', fn: () => Reports.allMeters() },
        { t: 'Single Meter Summary', d: 'Full report for one meter', ico: '📄', fn: () => Reports.singleMeter() },
        { t: 'Custom Report', d: 'Readings and bills for a date range', ico: '📅', fn: () => Reports.custom() }
      ];
      items.forEach(it => card.appendChild(el('div', { class: 'list-item', onclick: it.fn }, [
        el('div', { class: 'mc-avatar', text: it.ico }),
        el('div', { class: 'li-body' }, [el('div', { class: 'li-title', text: it.t }), el('div', { class: 'li-sub', text: it.d })]),
        el('div', { class: 'li-right', text: '›' })
      ])));
      wrap.appendChild(card);
      return wrap;
    },

    allMeters() {
      const meters = DB.all('meters');
      const bills = DB.all('bills');
      const stats = {
        total: meters.length,
        active: meters.filter(m => m.status === 'Active').length,
        stopped: meters.filter(m => m.status === 'Stopped').length,
        load: Load.totalKwAll(),
        paid: bills.reduce((s, b) => s + Number(b.paidAmount || 0), 0),
        outstanding: bills.reduce((s, b) => s + Number(b.outstanding || 0), 0)
      };
      const doc = Pdf.allMetersSummary(meters, stats);
      Reports.actions(doc, 'all-meters-summary.pdf');
    },

    singleMeter() {
      const meters = DB.all('meters');
      if (!meters.length) { toast('No meters available', 'warn'); return; }
      const content = el('div');
      const sel = el('select', { class: 'select', id: 'rep-meter' });
      meters.forEach(m => sel.appendChild(el('option', { value: m.id, text: m.meterNumber + ' — ' + m.name })));
      content.appendChild(field('Select Meter', sel));
      const sheet = openSheet({ title: 'Single Meter Summary', content });
      content.appendChild(el('button', { class: 'btn btn-primary btn-block mt16', text: 'Generate PDF', onclick: () => {
        const m = DB.get('meters', U.$('#rep-meter').value);
        const doc = Pdf.singleMeterSummary(m, DB.all('readings').filter(r => r.meterId === m.id),
          DB.all('bills').filter(b => b.meterId === m.id), DB.all('devices').filter(d => d.meterId === m.id));
        sheet.close(); Reports.actions(doc, 'meter-' + m.meterNumber + '.pdf');
      }}));
    },

    custom() {
      const content = el('div');
      content.appendChild(el('div', { class: 'field-row' }, [
        field('From Date', inputEl('rep-from', 'date', Fmt.today())),
        field('To Date', inputEl('rep-to', 'date', Fmt.today()))
      ]));
      const sheet = openSheet({ title: 'Custom Report', content });
      content.appendChild(el('button', { class: 'btn btn-primary btn-block mt16', text: 'Generate PDF', onclick: () => {
        const from = U.$('#rep-from').value, to = U.$('#rep-to').value;
        const doc = Pdf.customReport(from, to, DB.all('meters'), DB.all('readings'), DB.all('bills'));
        sheet.close(); Reports.actions(doc, 'custom-report.pdf');
      }}));
    },

    actions(doc, filename) {
      const content = el('div');
      content.appendChild(el('div', { class: 'alert ok', text: 'Report generated successfully.' }));
      content.appendChild(el('div', { class: 'row' }, [
        el('button', { class: 'btn btn-primary', text: '💾 Save', style: 'flex:1', onclick: () => { Pdf.save(doc, filename); toast('Saved', 'ok'); } }),
        el('button', { class: 'btn btn-accent', text: '📤 Share', style: 'flex:1', onclick: () => Pdf.share(doc, filename) }),
        el('button', { class: 'btn btn-ghost', text: '🖨️ Print', style: 'flex:1', onclick: () => Pdf.print(doc) })
      ]));
      openSheet({ title: 'Report Ready', content });
    }
  };

  /* ============================================================
     SETTINGS (Owner)
     ============================================================ */
  const Settings = {
    render() {
      const wrap = el('div');
      const u = Auth.current;

      // account
      wrap.appendChild(el('div', { class: 'card' }, [
        el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '👤' }), 'Account']),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Name' }), el('span', { class: 'v', text: u.fullName })]),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Username' }), el('span', { class: 'v', text: u.username })]),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Role' }), el('span', { class: 'v', text: Auth.roleLabel(u.role) })])
      ]));

      // users
      const usersCard = el('div', { class: 'card' });
      usersCard.appendChild(el('div', { class: 'section-head' }, [
        el('h2', { text: '👥 User Management' }),
        el('button', { class: 'btn btn-primary btn-sm', text: '+ Add', onclick: () => Settings.userForm() })
      ]));
      DB.all('users').forEach(usr => {
        usersCard.appendChild(el('div', { class: 'list-item' }, [
          el('div', { class: 'li-body' }, [
            el('div', { class: 'li-title', text: usr.fullName + (usr.active ? '' : ' (disabled)') }),
            el('div', { class: 'li-sub', text: usr.username + ' • ' + Auth.roleLabel(usr.role) })
          ]),
          el('div', { class: 'li-right' }, [el('button', { class: 'btn btn-ghost btn-sm', text: '✏️', onclick: () => Settings.userForm(usr.id) })])
        ]));
      });
      wrap.appendChild(usersCard);

      // sync
      const s = DB.settings();
      const syncCard = el('div', { class: 'card' }, [
        el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '☁️' }), 'Cloud Sync']),
        field('Server URL', inputEl('set-endpoint', 'text', s.endpoint, 'https://your-server.onrender.com')),
        field('Hospital Code', inputEl('set-group', 'text', s.group || 'default', 'e.g. cityhospital')),
        field('API Token', inputEl('set-token', 'text', s.token, 'optional')),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Pending records' }), el('span', { class: 'v', text: String(Sync.pendingCount()) })]),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Last sync' }), el('span', { class: 'v', text: s.lastSync ? Fmt.dateTime(s.lastSync) : 'Never' })]),
        el('div', { class: 'row mt12' }, [
          el('button', { class: 'btn btn-ghost', text: 'Save', style: 'flex:1', onclick: () => {
            DB.setSettings({ endpoint: U.$('#set-endpoint').value.trim(), group: U.$('#set-group').value.trim() || 'default', token: U.$('#set-token').value.trim() });
            toast('Sync settings saved', 'ok');
          }}),
          el('button', { class: 'btn btn-soft', text: '🔌 Test', style: 'flex:1', onclick: () => Sync.testConnection() })
        ]),
        el('div', { class: 'row mt8' }, [
          el('button', { class: 'btn btn-primary btn-block', text: '🔄 Sync Now', onclick: () => Sync.syncNow() })
        ])
      ]);
      wrap.appendChild(syncCard);

      // backup
      const backupCard = el('div', { class: 'card' }, [
        el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '💾' }), 'Backup & Export']),
        el('div', { class: 'row wrap' }, [
          el('button', { class: 'btn btn-soft btn-sm', text: '⬇️ Backup JSON', onclick: () => Backup.exportJson() }),
          el('button', { class: 'btn btn-soft btn-sm', text: '⬆️ Restore', onclick: () => Settings.restore() }),
          el('button', { class: 'btn btn-soft btn-sm', text: '📄 Meters CSV', onclick: () => Backup.exportMetersCsv() }),
          el('button', { class: 'btn btn-soft btn-sm', text: '📄 Readings CSV', onclick: () => Backup.exportReadingsCsv() }),
          el('button', { class: 'btn btn-soft btn-sm', text: '📄 Bills CSV', onclick: () => Backup.exportBillsCsv() })
        ])
      ]);
      wrap.appendChild(backupCard);

      // about
      wrap.appendChild(el('div', { class: 'card' }, [
        el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: 'ℹ️' }), 'About']),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'App' }), el('span', { class: 'v', text: U.BRAND.appName })]),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Version' }), el('span', { class: 'v', text: '1.0.0 (1)' })]),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Developer' }), el('span', { class: 'v', text: U.BRAND.developer })]),
        el('div', { class: 'kv' }, [el('span', { class: 'k', text: 'Contact' }), el('span', { class: 'v', text: U.BRAND.phone })])
      ]));

      wrap.appendChild(el('button', { class: 'btn btn-danger btn-block', text: 'Logout', onclick: () => App.logout() }));
      wrap.appendChild(el('div', { class: 'branding', html: 'Software Developed By <b>Tech Arslan Software Solutions</b><br>03200199895' }));
      return wrap;
    },

    userForm(userId) {
      const usr = userId ? DB.get('users', userId) : null;
      const content = el('div');
      content.appendChild(field('Full Name', inputEl('u-name', 'text', usr ? usr.fullName : ''), true));
      content.appendChild(field('Username', inputEl('u-username', 'text', usr ? usr.username : ''), true));
      content.appendChild(field(usr ? 'New Password (leave blank to keep)' : 'Password', inputEl('u-password', 'password', ''), !usr));
      content.appendChild(field('Role', selectEl('u-role', ['owner', 'manager', 'electrician'], usr ? usr.role : 'electrician')));
      if (usr) content.appendChild(field('Active', selectEl('u-active', ['true', 'false'], String(usr.active))));

      const sheet = openSheet({ title: usr ? 'Edit User' : 'Add User', content });
      content.appendChild(el('div', { class: 'row mt16' }, [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', style: 'flex:1', onclick: () => sheet.close() }),
        el('button', { class: 'btn btn-primary', text: 'Save', style: 'flex:1', onclick: () => {
          const name = U.$('#u-name').value.trim();
          const username = U.$('#u-username').value.trim();
          const password = U.$('#u-password').value;
          const role = U.$('#u-role').value;
          if (!name || !username) { toast('Name and username required', 'err'); return; }
          if (usr) {
            const patch = { fullName: name, username, role };
            if (U.$('#u-active')) patch.active = U.$('#u-active').value === 'true';
            if (password) patch.password = password;
            Auth.updateUser(usr.id, patch); toast('User updated', 'ok');
          } else {
            if (!password) { toast('Password required', 'err'); return; }
            const res = Auth.createUser({ fullName: name, username, password, role });
            if (!res.ok) { toast(res.error, 'err'); return; }
            toast('User created', 'ok');
          }
          sheet.close(); App.render();
        }})
      ]));
    },

    restore() {
      const input = el('input', { type: 'file', accept: '.json,application/json', style: 'display:none' });
      input.addEventListener('change', () => {
        if (input.files[0]) Backup.importJson(input.files[0], () => App.render());
      });
      document.body.appendChild(input);
      input.click();
      setTimeout(() => input.remove(), 1000);
    }
  };

  /* ============================================================
     PROFILE (Manager / Electrician)
     ============================================================ */
  const Profile = {
    render() {
      const wrap = el('div');
      const u = Auth.current;
      wrap.appendChild(el('div', { class: 'card' }, [
        el('div', { class: 'row' }, [
          el('div', { class: 'mc-avatar', text: '👤' }),
          el('div', { style: 'flex:1' }, [
            el('div', { class: 'mc-name', text: u.fullName }),
            el('div', { class: 'mc-meta', text: '@' + u.username + ' • ' + Auth.roleLabel(u.role) })
          ])
        ])
      ]));

      const perms = el('div', { class: 'card' }, [el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '🔐' }), 'Permissions'])]);
      const P = Permissions;
      [['Manage Meters', P.canManageMeters(u.role)], ['Manage Bills', P.canManageBills(u.role)],
       ['Enter Readings', P.canManageReadings(u.role)], ['Manage Load', P.canManageLoad(u.role)],
       ['View Reports', P.canViewReports(u.role)], ['Manage Users', P.canManageUsers(u.role)],
       ['Backup / Restore', P.canBackup(u.role)]]
        .forEach(p => perms.appendChild(el('div', { class: 'kv' }, [
          el('span', { class: 'k', text: p[0] }),
          el('span', { class: 'v', text: p[1] ? '✅ Allowed' : '⛔ Not allowed' })
        ])));
      wrap.appendChild(perms);

      if (u.role === 'electrician') {
        const assigned = DB.all('meters').filter(m => (u.assignedMeterIds || []).includes(m.id));
        const card = el('div', { class: 'card' }, [el('div', { class: 'card-title' }, [el('span', { class: 'ico', text: '⚡' }), 'Assigned Meters'])]);
        if (!assigned.length) card.appendChild(el('div', { class: 'empty' }, [el('p', { text: 'No meters assigned yet' })]));
        assigned.forEach(m => card.appendChild(el('div', { class: 'list-item' }, [
          el('div', { class: 'li-body' }, [el('div', { class: 'li-title', text: m.name }), el('div', { class: 'li-sub', text: 'Meter ' + m.meterNumber })])
        ])));
        wrap.appendChild(card);
      }

      wrap.appendChild(el('button', { class: 'btn btn-soft btn-block', text: '🔑 Change Password', onclick: () => Profile.changePassword() }));
      wrap.appendChild(el('button', { class: 'btn btn-danger btn-block mt8', text: 'Logout', onclick: () => App.logout() }));
      wrap.appendChild(el('div', { class: 'branding', html: 'Software Developed By <b>Tech Arslan Software Solutions</b><br>03200199895' }));
      return wrap;
    },

    changePassword() {
      const content = el('div');
      content.appendChild(field('Current Password', inputEl('cp-old', 'password', ''), true));
      content.appendChild(field('New Password', inputEl('cp-new', 'password', ''), true));
      const sheet = openSheet({ title: 'Change Password', content });
      content.appendChild(el('button', { class: 'btn btn-primary btn-block mt16', text: 'Update Password', onclick: () => {
        const res = Auth.changePassword(Auth.current.id, U.$('#cp-old').value, U.$('#cp-new').value);
        if (!res.ok) { toast(res.error, 'err'); return; }
        toast('Password updated', 'ok'); sheet.close();
      }}));
    }
  };

  global.Views = { Dashboard, Meters, MeterDetail, Readings, Bills, Devices, Reports, Settings, Profile };
})(window);
