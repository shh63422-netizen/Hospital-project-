/* ============================================================
   PDF — professional reports with branding (jsPDF)
   Branding: "Software Developed By Tech Arslan Software Solutions 03200199895"
   ============================================================ */
(function (global) {
  'use strict';

  const GREEN = [11, 110, 79];
  const DARK = [26, 32, 39];
  const GREY = [90, 102, 114];
  const LIGHT = [244, 246, 248];

  function newDoc() {
    const { jsPDF } = global.jspdf;
    return new jsPDF({ unit: 'pt', format: 'a4' });
  }

  function header(doc, title, subtitle) {
    const W = doc.internal.pageSize.getWidth();
    // green band
    doc.setFillColor.apply(doc, GREEN);
    doc.rect(0, 0, W, 74, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(17);
    doc.text('Hospital Meter Manager', 40, 32);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text('Electricity Meter Management & Supervision', 40, 50);
    doc.setFontSize(9);
    doc.text('Tech Arslan Software Solutions', W - 40, 32, { align: 'right' });
    doc.text('03200199895', W - 40, 48, { align: 'right' });

    doc.setTextColor.apply(doc, DARK);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text(title, 40, 104);
    if (subtitle) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor.apply(doc, GREY);
      doc.text(subtitle, 40, 120);
    }
    doc.setTextColor.apply(doc, DARK);
    return 138;
  }

  function footer(doc) {
    const W = doc.internal.pageSize.getWidth();
    const H = doc.internal.pageSize.getHeight();
    const pages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pages; i++) {
      doc.setPage(i);
      doc.setDrawColor(226, 232, 238);
      doc.line(40, H - 46, W - 40, H - 46);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor.apply(doc, GREY);
      doc.text('Software Developed By Tech Arslan Software Solutions 03200199895', 40, H - 30);
      doc.text('Page ' + i + ' of ' + pages, W - 40, H - 30, { align: 'right' });
    }
  }

  function table(doc, startY, columns, rows, opts) {
    opts = opts || {};
    const W = doc.internal.pageSize.getWidth();
    const marginX = 40;
    const tableW = W - marginX * 2;
    const colW = opts.colWidths || columns.map(() => tableW / columns.length);
    const rowH = 20;
    let y = startY;

    function drawHead() {
      doc.setFillColor.apply(doc, GREEN);
      doc.rect(marginX, y, tableW, rowH, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      let x = marginX;
      columns.forEach((c, i) => {
        const align = (opts.align && opts.align[i]) || 'left';
        const tx = align === 'right' ? x + colW[i] - 6 : x + 6;
        doc.text(String(c), tx, y + 13, { align: align === 'right' ? 'right' : 'left' });
        x += colW[i];
      });
      y += rowH;
    }

    drawHead();
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);

    rows.forEach((r, ri) => {
      if (y > doc.internal.pageSize.getHeight() - 70) {
        footer(doc);
        doc.addPage();
        y = 60;
        drawHead();
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
      }
      if (ri % 2 === 1) {
        doc.setFillColor.apply(doc, LIGHT);
        doc.rect(marginX, y, tableW, rowH, 'F');
      }
      doc.setTextColor.apply(doc, DARK);
      let x = marginX;
      r.forEach((cell, i) => {
        const align = (opts.align && opts.align[i]) || 'left';
        const tx = align === 'right' ? x + colW[i] - 6 : x + 6;
        const txt = doc.splitTextToSize(String(cell == null ? '' : cell), colW[i] - 10)[0] || '';
        doc.text(txt, tx, y + 13, { align: align === 'right' ? 'right' : 'left' });
        x += colW[i];
      });
      y += rowH;
    });
    return y;
  }

  function summaryBox(doc, y, items) {
    const W = doc.internal.pageSize.getWidth();
    const marginX = 40;
    const boxW = W - marginX * 2;
    const perRow = 3;
    const cellW = boxW / perRow;
    const cellH = 46;
    let row = 0;
    items.forEach((it, i) => {
      const col = i % perRow;
      if (col === 0 && i > 0) row++;
      const x = marginX + col * cellW;
      const yy = y + row * cellH;
      doc.setFillColor.apply(doc, LIGHT);
      doc.roundedRect(x + 3, yy, cellW - 6, cellH - 8, 5, 5, 'F');
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor.apply(doc, GREY);
      doc.text(it.label, x + 12, yy + 15);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor.apply(doc, GREEN);
      doc.text(String(it.value), x + 12, yy + 32);
    });
    return y + (row + 1) * cellH + 6;
  }

  const Pdf = {
    /* ---- All meters summary ---- */
    allMetersSummary(meters, stats) {
      const doc = newDoc();
      let y = header(doc, 'All Meters Summary', 'Generated: ' + U.Fmt.dateTime(new Date()));

      y = summaryBox(doc, y, [
        { label: 'Total Meters', value: stats.total },
        { label: 'Active Meters', value: stats.active },
        { label: 'Stopped Meters', value: stats.stopped },
        { label: 'Total Connected Load', value: U.Fmt.number(stats.load, 2) + ' kW' },
        { label: 'Total Outstanding', value: U.Fmt.money(stats.outstanding) },
        { label: 'Total Paid', value: U.Fmt.money(stats.paid) }
      ]);

      const cols = ['#', 'Meter No', 'Customer', 'Department', 'Location', 'Status', 'Load kW'];
      const widths = [22, 78, 110, 90, 90, 55, 55];
      const rows = meters.map((m, i) => [
        i + 1, m.meterNumber, m.name, m.department || '—', m.location || '—', m.status,
        U.Fmt.number(Load.totalKw(m.id), 2)
      ]);
      y = table(doc, y, cols, rows, { colWidths: widths, align: ['left', 'left', 'left', 'left', 'left', 'left', 'right'] });

      footer(doc);
      return doc;
    },

    /* ---- Single meter summary ---- */
    singleMeterSummary(meter, readings, bills, devices) {
      const doc = newDoc();
      let y = header(doc, 'Meter Summary', meter.meterNumber + ' — ' + meter.name);

      const info = [
        ['Meter Number', meter.meterNumber], ['Customer ID', meter.customerId || '—'],
        ['Name / Department', meter.name], ['Department', meter.department || '—'],
        ['Location', meter.location || '—'], ['Status', meter.status],
        ['Start Date', U.Fmt.date(meter.startDate)], ['Stop Date', meter.stopDate ? U.Fmt.date(meter.stopDate) : '—'],
        ['Initial Units', U.Fmt.number(meter.initialUnits, 2)], ['Total Connected Load', U.Fmt.number(Load.totalKw(meter.id), 2) + ' kW']
      ];
      doc.setFontSize(9);
      info.forEach((kv, i) => {
        const col = i % 2;
        const row = Math.floor(i / 2);
        const x = 40 + col * 260;
        const yy = y + row * 18;
        doc.setFont('helvetica', 'normal');
        doc.setTextColor.apply(doc, GREY);
        doc.text(kv[0] + ':', x, yy);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor.apply(doc, DARK);
        doc.text(String(kv[1]), x + 105, yy);
      });
      y += Math.ceil(info.length / 2) * 18 + 14;

      // readings
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor.apply(doc, DARK);
      doc.text('Unit Readings', 40, y); y += 8;
      const rRows = readings.slice().sort((a, b) => (a.date < b.date ? 1 : -1)).map(r => [
        U.Fmt.date(r.date), U.Fmt.number(r.units, 2), U.Fmt.number(r.consumption, 2)
      ]);
      y = table(doc, y, ['Date', 'Units', 'Consumption'], rRows, { colWidths: [180, 160, 160], align: ['left', 'right', 'right'] });
      y += 16;

      // bills
      if (y > doc.internal.pageSize.getHeight() - 120) { footer(doc); doc.addPage(); y = 60; }
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor.apply(doc, DARK);
      doc.text('Bills', 40, y); y += 8;
      const bRows = bills.slice().sort((a, b) => (a.billingMonth < b.billingMonth ? 1 : -1)).map(b => [
        U.Fmt.monthLabel(b.billingMonth), U.Fmt.money(b.billAmount), U.Fmt.money(b.paidAmount),
        U.Fmt.money(b.outstanding), b.paymentStatus
      ]);
      y = table(doc, y, ['Month', 'Bill', 'Paid', 'Outstanding', 'Status'], bRows,
        { colWidths: [110, 110, 110, 110, 60], align: ['left', 'right', 'right', 'right', 'left'] });
      y += 16;

      // devices
      if (y > doc.internal.pageSize.getHeight() - 120) { footer(doc); doc.addPage(); y = 60; }
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor.apply(doc, DARK);
      doc.text('Connected Load / Devices', 40, y); y += 8;
      const dRows = devices.map(d => [
        d.name, d.category, d.quantity, U.Fmt.number(d.voltage, 0), U.Fmt.number(d.ampere, 2), U.Fmt.number(d.effectiveKw, 3)
      ]);
      y = table(doc, y, ['Device', 'Category', 'Qty', 'Volt', 'Amp', 'kW'], dRows,
        { colWidths: [130, 110, 40, 55, 55, 110], align: ['left', 'left', 'right', 'right', 'right', 'right'] });

      footer(doc);
      return doc;
    },

    /* ---- Custom range report ---- */
    customReport(from, to, meters, readings, bills) {
      const doc = newDoc();
      let y = header(doc, 'Custom Report', 'Period: ' + U.Fmt.date(from) + '  to  ' + U.Fmt.date(to));

      const inRangeReadings = readings.filter(r => U.Fmt.inRange(r.date, from, to));
      const inRangeBills = bills.filter(b => U.Fmt.inRange(b.billDate, from, to));
      const totalUnits = inRangeReadings.reduce((s, r) => s + Number(r.consumption || 0), 0);
      const totalBill = inRangeBills.reduce((s, b) => s + Number(b.billAmount || 0), 0);
      const totalPaid = inRangeBills.reduce((s, b) => s + Number(b.paidAmount || 0), 0);
      const totalOut = inRangeBills.reduce((s, b) => s + Number(b.outstanding || 0), 0);

      y = summaryBox(doc, y, [
        { label: 'Meters', value: meters.length },
        { label: 'Readings', value: inRangeReadings.length },
        { label: 'Total Units', value: U.Fmt.number(totalUnits, 2) },
        { label: 'Total Bill', value: U.Fmt.money(totalBill) },
        { label: 'Total Paid', value: U.Fmt.money(totalPaid) },
        { label: 'Outstanding', value: U.Fmt.money(totalOut) }
      ]);

      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor.apply(doc, DARK);
      doc.text('Readings in Period', 40, y); y += 8;
      const rRows = inRangeReadings.slice().sort((a, b) => (a.date < b.date ? 1 : -1)).map(r => {
        const m = meters.find(x => x.id === r.meterId);
        return [U.Fmt.date(r.date), m ? m.meterNumber : '—', m ? m.name : '—', U.Fmt.number(r.units, 2), U.Fmt.number(r.consumption, 2)];
      });
      y = table(doc, y, ['Date', 'Meter No', 'Name', 'Units', 'Consumption'], rRows,
        { colWidths: [80, 90, 150, 90, 90], align: ['left', 'left', 'left', 'right', 'right'] });
      y += 16;

      if (y > doc.internal.pageSize.getHeight() - 120) { footer(doc); doc.addPage(); y = 60; }
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor.apply(doc, DARK);
      doc.text('Bills in Period', 40, y); y += 8;
      const bRows = inRangeBills.slice().sort((a, b) => (a.billDate < b.billDate ? 1 : -1)).map(b => {
        const m = meters.find(x => x.id === b.meterId);
        return [U.Fmt.date(b.billDate), m ? m.meterNumber : '—', U.Fmt.money(b.billAmount), U.Fmt.money(b.paidAmount), U.Fmt.money(b.outstanding), b.paymentStatus];
      });
      y = table(doc, y, ['Date', 'Meter No', 'Bill', 'Paid', 'Outstanding', 'Status'], bRows,
        { colWidths: [70, 80, 90, 90, 90, 80], align: ['left', 'left', 'right', 'right', 'right', 'left'] });

      footer(doc);
      return doc;
    },

    /* ---- helpers to save / share / print ---- */
    _bridge() { return (typeof window !== 'undefined' && window.AndroidBridge) ? window.AndroidBridge : null; },
    _b64(doc) { return doc.output('datauristring').split(',')[1]; },

    save(doc, filename) {
      const b = Pdf._bridge();
      if (b && b.savePdf) { b.savePdf(Pdf._b64(doc), filename); U.toast('Report saved', 'ok'); return; }
      doc.save(filename);
    },
    blobUrl(doc) {
      return doc.output('bloburl');
    },
    print(doc) {
      const b = Pdf._bridge();
      if (b && b.printPdf) { b.printPdf(Pdf._b64(doc), 'report.pdf'); return; }
      doc.autoPrint();
      const url = doc.output('bloburl');
      const w = window.open(url, '_blank');
      if (!w) U.toast('Allow pop-ups to print', 'warn');
    },
    async share(doc, filename) {
      const b = Pdf._bridge();
      if (b && b.sharePdf) { b.sharePdf(Pdf._b64(doc), filename); return; }
      try {
        const blob = doc.output('blob');
        const file = new File([blob], filename, { type: 'application/pdf' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
        } else {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url; a.download = filename; a.click();
          setTimeout(() => URL.revokeObjectURL(url), 4000);
          U.toast('PDF downloaded', 'ok');
        }
      } catch (e) {
        U.toast('Share cancelled', 'warn');
      }
    }
  };

  global.Pdf = Pdf;
})(window);
