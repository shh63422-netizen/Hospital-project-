/* ============================================================
   Util — formatters, ids, toasts, modals, DOM helpers
   ============================================================ */
(function (global) {
  'use strict';

  const BRAND = {
    appName: 'Hospital Meter Manager',
    developer: 'Tech Arslan Software Solutions',
    phone: '03200199895',
    line: 'Software Developed By Tech Arslan Software Solutions 03200199895'
  };

  const ROLES = { OWNER: 'owner', MANAGER: 'manager', ELECTRICIAN: 'electrician' };
  const METER_STATUS = ['Active', 'Stopped', 'Faulty', 'Removed'];
  const PAY_STATUS = ['Paid', 'Partially Paid', 'Unpaid'];
  const DEVICE_CATEGORIES = ['Lighting', 'Air Conditioner', 'Fan', 'Computer', 'Medical Equipment',
    'Refrigerator', 'Water Pump', 'Heater', 'Ventilator', 'X-Ray / Imaging', 'Other'];

  function uid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  const Fmt = {
    date(d) {
      if (!d) return '—';
      const dt = (d instanceof Date) ? d : new Date(d);
      if (isNaN(dt)) return '—';
      return pad(dt.getDate()) + '-' + pad(dt.getMonth() + 1) + '-' + dt.getFullYear();
    },
    dateTime(d) {
      if (!d) return '—';
      const dt = (d instanceof Date) ? d : new Date(d);
      if (isNaN(dt)) return '—';
      return Fmt.date(dt) + ' ' + pad(dt.getHours()) + ':' + pad(dt.getMinutes());
    },
    monthKey(d) {
      const dt = (d instanceof Date) ? d : new Date(d);
      return dt.getFullYear() + '-' + pad(dt.getMonth() + 1);
    },
    monthLabel(key) {
      if (!key) return '—';
      const [y, m] = key.split('-');
      const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return names[parseInt(m, 10) - 1] + ' ' + y;
    },
    money(n) {
      const v = Number(n || 0);
      return 'Rs ' + v.toLocaleString('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    },
    number(n, dec) {
      const v = Number(n || 0);
      return v.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: dec == null ? 2 : dec });
    },
    iso(d) {
      const dt = (d instanceof Date) ? d : new Date(d);
      return dt.toISOString();
    },
    dateOnly(d) {
      const dt = (d instanceof Date) ? d : new Date(d);
      return dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate());
    },
    today() { return Fmt.dateOnly(new Date()); },
    inRange(dateStr, from, to) {
      if (!dateStr) return false;
      const d = dateStr.slice(0, 10);
      if (from && d < from) return false;
      if (to && d > to) return false;
      return true;
    }
  };

  /* ---------- DOM ---------- */
  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      for (const k in attrs) {
        if (k === 'class') node.className = attrs[k];
        else if (k === 'html') node.innerHTML = attrs[k];
        else if (k === 'text') node.textContent = attrs[k];
        else if (k.startsWith('on') && typeof attrs[k] === 'function') node.addEventListener(k.slice(2), attrs[k]);
        else if (attrs[k] != null) node.setAttribute(k, attrs[k]);
      }
    }
    (children || []).forEach(c => {
      if (c == null) return;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return node;
  }
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ---------- Toast ---------- */
  function toast(msg, type) {
    const wrap = document.getElementById('toast-wrap');
    const t = el('div', { class: 'toast ' + (type || ''), text: msg });
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 2400);
    setTimeout(() => t.remove(), 2800);
  }

  /* ---------- Modal / bottom sheet ---------- */
  function openSheet(opts) {
    const root = document.getElementById('modal-root');
    const overlay = el('div', { class: 'overlay' });
    const sheet = el('div', { class: 'sheet' });
    const head = el('div', { class: 'sheet-head' }, [
      el('h3', { text: opts.title || '' }),
      el('button', { class: 'btn btn-ghost btn-icon', text: '✕', onclick: close })
    ]);
    const body = el('div', { class: 'sheet-body' });
    if (opts.content) body.appendChild(opts.content);
    sheet.appendChild(el('div', { class: 'sheet-grab' }));
    sheet.appendChild(head);
    sheet.appendChild(body);
    overlay.appendChild(sheet);
    overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    root.appendChild(overlay);

    function close() { overlay.remove(); if (opts.onClose) opts.onClose(); }
    return { close, body, sheet };
  }

  function confirmDialog(title, message, onYes, yesLabel) {
    const content = el('div', {}, [
      el('p', { class: 'muted', text: message, style: 'margin:0 0 16px' }),
      el('div', { class: 'row' }, [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', style: 'flex:1', onclick: () => s.close() }),
        el('button', { class: 'btn btn-danger', text: yesLabel || 'Delete', style: 'flex:1', onclick: () => { s.close(); onYes(); } })
      ])
    ]);
    const s = openSheet({ title: title, content: content });
  }

  global.U = {
    BRAND, ROLES, METER_STATUS, PAY_STATUS, DEVICE_CATEGORIES,
    uid, Fmt, el, esc, $, $$, toast, openSheet, confirmDialog
  };
})(window);
