/* ============================================================
   Sync — offline-first sync engine
   States: offline | online | syncing | synced | error
   ============================================================ */
(function (global) {
  'use strict';

  const Sync = {
    state: 'offline',
    lastError: '',
    listeners: [],

    init() {
      window.addEventListener('online', () => Sync.refresh());
      window.addEventListener('offline', () => Sync.refresh());
      Sync.refresh();
      setInterval(Sync.refresh, 15000);
    },

    on(fn) { Sync.listeners.push(fn); },
    emit() { Sync.listeners.forEach(fn => { try { fn(Sync.state, Sync.lastError); } catch (e) {} }); },

    isOnline() { return navigator.onLine; },

    refresh() {
      if (Sync.state === 'syncing') return;
      Sync.state = Sync.isOnline() ? 'online' : 'offline';
      Sync.emit();
    },

    label() {
      return { offline: 'Offline', online: 'Online', syncing: 'Syncing…', synced: 'Synced', error: 'Sync Error' }[Sync.state] || 'Offline';
    },

    pendingCount() { return DB.pendingCount(); },

    async syncNow() {
      const s = DB.settings();
      if (!Sync.isOnline()) { Sync.state = 'offline'; Sync.emit(); U.toast('No internet connection', 'warn'); return; }
      if (!s.endpoint) { U.toast('Set a cloud endpoint in Settings first', 'warn'); return; }

      Sync.state = 'syncing'; Sync.emit();
      try {
        const payload = { deviceId: s.deviceId, sentAt: new Date().toISOString(), changes: {} };
        DB.COLLECTIONS.forEach(c => { payload.changes[c] = DB.pending(c); });

        const res = await fetch(s.endpoint, {
          method: 'POST',
          headers: Object.assign({ 'Content-Type': 'application/json' }, s.token ? { 'Authorization': 'Bearer ' + s.token } : {}),
          body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error('Server responded ' + res.status);

        // mark all pushed records synced
        DB.COLLECTIONS.forEach(c => {
          const ids = payload.changes[c].map(r => r.id);
          if (ids.length) DB.markSynced(c, ids);
        });
        DB.setSettings({ lastSync: new Date().toISOString() });
        Sync.state = 'synced'; Sync.emit();
        U.toast('Sync completed', 'ok');
      } catch (e) {
        Sync.state = 'error'; Sync.lastError = e.message || 'Sync failed'; Sync.emit();
        U.toast('Sync error: ' + Sync.lastError, 'err');
      }
    }
  };

  global.Sync = Sync;
})(window);
