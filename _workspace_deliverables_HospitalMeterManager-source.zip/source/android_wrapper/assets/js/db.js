/* ============================================================
   DB — offline-first local store (localStorage backed)
   Every record carries: id, createdAt, updatedAt, syncStatus, deleted
   ============================================================ */
(function (global) {
  'use strict';

  const PREFIX = 'hmm_';
  const COLLECTIONS = ['users', 'meters', 'readings', 'bills', 'devices'];
  const SETTINGS_KEY = PREFIX + 'settings';

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }
  function write(key, val) {
    localStorage.setItem(PREFIX + key, JSON.stringify(val));
  }

  const DB = {
    COLLECTIONS,

    init() {
      COLLECTIONS.forEach(c => { if (read(c, null) === null) write(c, []); });
      if (read('settings', null) === null) {
        write('settings', {
          endpoint: '',
          token: '',
          lastSync: null,
          deviceId: 'dev-' + Math.random().toString(36).slice(2, 10)
        });
      }
    },

    /* ---------- generic CRUD ---------- */
    all(coll) { return read(coll, []).filter(r => !r.deleted); },
    allRaw(coll) { return read(coll, []); },
    get(coll, id) { return read(coll, []).find(r => r.id === id) || null; },

    insert(coll, rec) {
      const list = read(coll, []);
      list.push(rec);
      write(coll, list);
      return rec;
    },
    update(coll, id, patch) {
      const list = read(coll, []);
      const i = list.findIndex(r => r.id === id);
      if (i < 0) return null;
      list[i] = Object.assign({}, list[i], patch, { updatedAt: new Date().toISOString() });
      write(coll, list);
      return list[i];
    },
    remove(coll, id) {
      // soft delete so the deletion can propagate on sync
      return DB.update(coll, id, { deleted: true, syncStatus: 'pending' });
    },
    hardRemove(coll, id) {
      write(coll, read(coll, []).filter(r => r.id !== id));
    },

    /* ---------- settings ---------- */
    settings() { return read('settings', {}); },
    setSettings(patch) {
      const s = Object.assign({}, read('settings', {}), patch);
      write('settings', s);
      return s;
    },

    /* ---------- sync helpers ---------- */
    pending(coll) {
      return read(coll, []).filter(r => r.syncStatus === 'pending');
    },
    markSynced(coll, ids) {
      const set = new Set(ids);
      const list = read(coll, []).map(r => set.has(r.id) ? Object.assign({}, r, { syncStatus: 'synced' }) : r);
      write(coll, list);
    },
    pendingCount() {
      return COLLECTIONS.reduce((n, c) => n + DB.pending(c).length, 0);
    },

    /* ---------- backup / restore ---------- */
    exportAll() {
      const out = { app: 'Hospital Meter Manager', version: 1, exportedAt: new Date().toISOString(), data: {} };
      COLLECTIONS.forEach(c => { out.data[c] = read(c, []); });
      out.data.settings = read('settings', {});
      return out;
    },
    importAll(obj) {
      if (!obj || !obj.data) throw new Error('Invalid backup file');
      COLLECTIONS.forEach(c => { if (Array.isArray(obj.data[c])) write(c, obj.data[c]); });
      if (obj.data.settings) write('settings', obj.data.settings);
    },
    wipe() {
      COLLECTIONS.forEach(c => write(c, []));
    }
  };

  global.DB = DB;
})(window);
